s = ""
for i in input().split("-"):
	s=s+i[0]
print(s)
