import java.util.Scanner;
class Bijele
{
	public static void main(String args[]){
        Scanner in = new Scanner(System.in);
	   	System.out.printf("%d ", 1-in.nextInt());
	   	System.out.printf("%d ", 1-in.nextInt());
	   	System.out.printf("%d ", 2-in.nextInt());
	   	System.out.printf("%d ", 2-in.nextInt());
	   	System.out.printf("%d ", 2-in.nextInt());
	   	System.out.printf("%d", 8-in.nextInt());
	   	}
}
