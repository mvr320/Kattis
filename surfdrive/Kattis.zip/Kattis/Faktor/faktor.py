import math
i = input().split()
A = float(i[0])
I = float(i[1])
print(math.ceil((I-0.99999)*A))
