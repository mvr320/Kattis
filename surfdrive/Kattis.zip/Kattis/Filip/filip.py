i = input().split()
a = int(i[0][::-1])
b = int(i[1][::-1])
print(a) if a>b else print(b)
