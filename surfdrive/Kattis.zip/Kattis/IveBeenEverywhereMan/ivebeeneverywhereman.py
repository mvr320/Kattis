t = int(input())
for i in range(t):
	r = set()
	c = int(input())
	for j in range(c):
		r.add(input())
	print(len(r))
