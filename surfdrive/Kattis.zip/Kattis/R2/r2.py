l = input().split()
r1 = int(l[0])
s = int(l[1])
print( (s*2)-r1 )
