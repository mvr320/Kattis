x = int(input())
n = int(input())
s = x
for i in range(n):
	s+=(x-int(input()))
print(s)
